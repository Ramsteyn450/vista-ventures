// config/db.js
// This file handles the connection to the MongoDB database.

const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        // Attempt to connect to MongoDB using the URI from environment variables
        const conn = await mongoose.connect(process.env.MONGO_URI, {
            useNewUrlParser: true,      // Deprecated, but good practice to include for older versions
            useUnifiedTopology: true    // Use new server discovery and monitoring engine
            // useCreateIndex: true,    // Deprecated, no longer needed in Mongoose 6+
            // useFindAndModify: false  // Deprecated, no longer needed in Mongoose 6+
        });

        console.log(`MongoDB Connected: ${conn.connection.host}`);
    } catch (error) {
        console.error(`Error: ${error.message}`);
        // Exit process with failure
        process.exit(1);
    }
};

module.exports = connectDB;

