// Application State
let currentUser = null; // Stores the logged-in user's info
let isAdmin = false; // Flag to check if the current user is an admin
let currentPage = 'dashboard'; // Tracks the currently active page

// Mock Data (for frontend simulation)
let products = [
    { id: 'p1', name: 'Wireless Headphones', price: 59.99, image: 'https://placehold.co/400x300/4A90E2/ffffff?text=Headphones', description: 'High-quality wireless headphones with noise cancellation and immersive sound.', rating: 4.5 },
    { id: 'p2', name: 'Smartwatch Pro', price: 189.99, image: 'https://placehold.co/400x300/6FCF97/ffffff?text=Smartwatch', description: 'Advanced smartwatch with health tracking, GPS, and long battery life.', rating: 4.8 },
    { id: 'p3', name: 'Portable Bluetooth Speaker', price: 49.99, image: 'https://placehold.co/400x300/EB5757/ffffff?text=Speaker', description: 'Compact speaker with powerful sound, waterproof design, and 20-hour playtime.', rating: 4.2 },
    { id: 'p4', name: 'USB-C Multiport Hub', price: 34.99, image: 'https://placehold.co/400x300/BB6BD9/ffffff?text=USB-C+Hub', description: '7-in-1 USB-C hub with HDMI, USB 3.0, and SD card reader.', rating: 4.0 },
    { id: 'p5', name: 'Ergonomic Vertical Mouse', price: 39.99, image: 'https://placehold.co/400x300/F2C94C/ffffff?text=Mouse', description: 'Comfortable ergonomic design reduces wrist strain for extended use.', rating: 4.7 },
    { id: 'p6', name: 'Full HD Webcam', price: 59.99, image: 'https://placehold.co/400x300/56CCF2/ffffff?text=Webcam', description: '1080p webcam with auto-focus and built-in microphone for clear video calls.', rating: 4.1 },
    { id: 'p7', name: 'Gaming Keyboard RGB', price: 79.99, image: 'https://placehold.co/400x300/4A90E2/ffffff?text=Gaming+Keyboard', description: 'Mechanical gaming keyboard with customizable RGB lighting and tactile switches.', rating: 4.6 },
    { id: 'p8', name: 'External SSD 1TB', price: 99.99, image: 'https://placehold.co/400x300/6FCF97/ffffff?text=External+SSD', description: 'Portable 1TB SSD for blazing-fast data transfer and reliable storage.', rating: 4.9 }
];

let cart = []; // Stores items in the shopping cart
let mockUsers = [ // Mock user data for admin view
    { id: 'u1', email: 'user@example.com', role: 'user', lastLogin: '2024-07-20 10:30 AM' },
    { id: 'u2', email: 'admin@example.com', role: 'admin', lastLogin: '2024-07-21 09:00 AM' },
    { id: 'u3', email: 'jane.doe@example.com', role: 'user', lastLogin: '2024-07-19 03:15 PM' },
    { id: 'u4', email: 'john.smith@example.com', role: 'user', lastLogin: '2024-07-18 11:45 AM' }
];

// Mock booking order state
let currentBooking = null; // Stores details of the active booking
let bookingStatusInterval = null; // Interval for simulating order status updates

// DOM Elements
const loginPage = document.getElementById('loginPage');
const mainApp = document.getElementById('mainApp');
const loginForm = document.getElementById('loginForm');
const passwordModal = document.getElementById('passwordModal');
const passwordForm = document.getElementById('passwordForm');
const paymentModal = document.getElementById('paymentModal');
const paymentForm = document.getElementById('paymentForm');

const userSettingsDropdownBtn = document.getElementById('userSettingsDropdownBtn'); // New settings button
const userManagementBtn = document.getElementById('userManagementBtn'); // New admin-only button in settings
const logoutBtn = document.getElementById('logoutBtn');
const changePasswordBtn = document.getElementById('changePasswordBtn');
const pageTitle = document.getElementById('pageTitle');
const cartItemCountSpan = document.getElementById('cartItemCount');
const productGrid = document.getElementById('productGrid');
const topSellingProductsGrid = document.getElementById('topSellingProductsGrid');
const cartItemsContainer = document.getElementById('cartItems');
const cartTotalSpan = document.getElementById('cartTotal');
const checkoutBtn = document.getElementById('checkoutBtn');
const addProductForm = document.getElementById('addProductForm');
const userListBody = document.getElementById('userListBody');
const adminOnlyNavItems = document.querySelectorAll('.nav-item.admin-only');
const messageBox = document.getElementById('messageBox');
const messageBoxTitle = document.getElementById('messageBoxTitle');
const messageBoxContent = document.getElementById('messageBoxContent');

// Payment Modal specific elements for card flip and validation
const paymentCard = document.getElementById('paymentCard');
const displayCardNumber = document.getElementById('displayCardNumber');
const displayCardName = document.getElementById('displayCardName');
const displayExpiryDate = document.getElementById('displayExpiryDate');
const displayCvv = document.getElementById('displayCvv');
const cardNumberInput = document.getElementById('cardNumber');
const expiryDateInput = document.getElementById('expiryDate');
const cvvInput = document.getElementById('cvv');
const cardNameInput = document.getElementById('cardName');
const paymentFeedback = document.getElementById('paymentFeedback');
const paymentMethodSelect = document.getElementById('paymentMethod');
const creditCardFields = document.getElementById('creditCardFields');
const paypalEmailContainer = document.getElementById('paypalEmailContainer');
const bankTransferInfoContainer = document.getElementById('bankTransferInfoContainer');
const paypalEmailInput = document.getElementById('paypalEmail');
const bankAccountInput = document.getElementById('bankAccount');

// Error message spans (ensure these elements exist in HTML)
const cardNumberError = document.getElementById('cardNumberError');
const expiryDateError = document.getElementById('expiryDateError');
const cvvError = document.getElementById('cvvError');
const cardNameError = document.getElementById('cardNameError');
const pickupAddressError = document.getElementById('pickupAddressError');
const deliveryAddressError = document.getElementById('deliveryAddressError');


// Loading Overlay
const loadingOverlay = document.getElementById('loadingOverlay');

// Chart.js instances
let revenueChartInstance = null;
let categoryChartInstance = null;

// User Profile Section elements
const profileUserName = document.getElementById('profileUserName');
const profileUserRole = document.getElementById('profileUserRole');
const profileLastLogin = document.getElementById('profileLastLogin');

// Booking Module elements
const bookingForm = document.getElementById('bookingForm');
const orderTrackingDisplay = document.getElementById('orderTrackingDisplay');
const bookingOrderStatus = document.getElementById('bookingOrderStatus');
const bookingLocationUpdate = document.getElementById('bookingLocationUpdate');
const currentLocationText = document.getElementById('currentLocationText');


// --- Utility Functions ---

/**
 * Displays a custom message box instead of alert().
 * @param {string} title - The title of the message box.
 * @param {string} message - The content message.
 */
function showMessageBox(title, message) {
    messageBoxTitle.textContent = title;
    messageBoxContent.textContent = message;
    messageBox.style.display = 'block';
    announceToScreenReader(`${title}. ${message}`);
}

/**
 * Closes a specified modal.
 * @param {string} modalId - The ID of the modal to close.
 */
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

/**
 * Shows the loading spinner overlay.
 */
function showLoadingSpinner() {
    loadingOverlay.style.display = 'flex';
}

/**
 * Hides the loading spinner overlay.
 */
function hideLoadingSpinner() {
    loadingOverlay.style.display = 'none';
}

/**
 * Announces a message to screen readers for accessibility.
 * @param {string} message - The message to announce.
 */
function announceToScreenReader(message) {
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'polite');
    announcement.setAttribute('aria-atomic', 'true');
    announcement.className = 'sr-only';
    announcement.textContent = message;

    document.body.appendChild(announcement);

    setTimeout(() => {
        document.body.removeChild(announcement);
    }, 1000);
}

/**
 * Generates star icons based on a rating.
 * @param {number} rating - The numerical rating (e.g., 4.5).
 * @returns {string} HTML string of star icons.
 */
function getStarRating(rating) {
    const fullStar = '<i class="fas fa-star"></i>';
    const halfStar = '<i class="fas fa-star-half-alt"></i>';
    const emptyStar = '<i class="far fa-star"></i>';
    let starsHtml = '';
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

    for (let i = 0; i < fullStars; i++) {
        starsHtml += fullStar;
    }
    if (hasHalfStar) {
        starsHtml += halfStar;
    }
    for (let i = 0; i < emptyStars; i++) {
        starsHtml += emptyStar;
    }
    return starsHtml;
}

/**
 * Displays an error message for a given input field.
 * @param {HTMLElement} errorElement - The span element to display the error.
 * @param {string} message - The error message.
 */
function showInputError(errorElement, message) {
    if (errorElement) { // Check if element exists before manipulating
        errorElement.textContent = message;
        errorElement.classList.add('active');
    }
}

/**
 * Hides an error message for a given input field.
 * @param {HTMLElement} errorElement - The span element displaying the error.
 */
function hideInputError(errorElement) {
    if (errorElement) { // Check if element exists before manipulating
        errorElement.textContent = '';
        errorElement.classList.remove('active');
    }
}

// --- Application Initialization ---

document.addEventListener('DOMContentLoaded', function() {
    // Check for existing session (mocked with localStorage)
    const savedUser = localStorage.getItem('marketUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        isAdmin = currentUser.role === 'admin';
        showMainApp();
    } else {
        showLoginPage();
    }
    setupEventListeners();
    loadCart(); // Load cart from local storage on setup
    updateCartItemCount();
    renderProducts(); // Render products on initial load
    renderTopSellingProducts(); // Render top selling products for dashboard
    renderOrders(); // Render orders on initial load (currently mock)
    setupLazyLoading(); // Initialize lazy loading for images
    loadModuleVisibility(); // Load module visibility preferences
});

// --- View Management ---

/**
 * Shows the login page and hides the main application.
 */
function showLoginPage() {
    loginPage.classList.add('active');
    mainApp.style.display = 'none';
    const emailInput = document.getElementById('email');
    if (emailInput) emailInput.focus();
    announceToScreenReader('Login page loaded.');
}

/**
 * Shows the main application and hides the login page.
 * Updates user display and admin panel visibility.
 */
function showMainApp() {
    loginPage.classList.remove('active');
    mainApp.style.display = 'flex';
    currentUserNameSpan.textContent = currentUser ? currentUser.email : 'Guest';
    profileUserName.textContent = currentUser ? currentUser.email : 'Guest User';
    profileUserRole.textContent = currentUser ? `Role: ${currentUser.role}` : 'Role: Visitor';
    profileLastLogin.textContent = currentUser ? `Last Login: ${currentUser.lastLogin || 'N/A'}` : 'Last Login: N/A';


    adminOnlyNavItems.forEach(item => {
        item.style.display = isAdmin ? 'block' : 'none';
    });
    // Show/hide admin-only user settings button
    if (userManagementBtn) {
        userManagementBtn.style.display = isAdmin ? 'block' : 'none';
    }

    // Navigate to dashboard by default after login
    handleNavigation({ target: document.querySelector('.nav-item[data-page="dashboard"]') });
    announceToScreenReader('Main application loaded.');
}

/**
 * Handles navigation between different pages/sections.
 * @param {Event} event - The click event.
 */
function handleNavigation(event) {
    const targetPage = event.target.closest('.nav-item, .quick-start-grid button').dataset.page;

    document.querySelectorAll('.page-content').forEach(page => {
        page.classList.remove('active');
    });

    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });

    const pageElement = document.getElementById(`${targetPage}Page`);
    if (pageElement) {
        pageElement.classList.add('active');
        // Update page title from the clicked nav item's text, or a default if from quick start
        const navItemText = event.target.closest('.nav-item') ? event.target.closest('.nav-item').textContent.trim() : event.target.textContent.trim();
        pageTitle.textContent = navItemText.replace('(<span id="cartItemCount">0</span>)', '').trim(); // Remove cart count from title
        
        // Add active class to the corresponding nav item if clicked from navigation
        const correspondingNavItem = document.querySelector(`.nav-item[data-page="${targetPage}"]`);
        if (correspondingNavItem) {
            correspondingNavItem.classList.add('active');
        }

        if (targetPage === 'products') {
            renderProducts();
            setupLazyLoading();
        } else if (targetPage === 'cart') {
            renderCart();
        } else if (targetPage === 'admin') {
            if (isAdmin) {
                renderUsers();
            } else {
                showMessageBox('Access Denied', 'You do not have administrative privileges.');
                handleNavigation({ target: document.querySelector('.nav-item[data-page="dashboard"]') });
            }
        } else if (targetPage === 'dashboard') {
            renderTopSellingProducts();
            setupLazyLoading();
            renderCharts(); // Render Chart.js charts when dashboard is active
            applyModuleVisibility(); // Apply user's module preferences
        } else if (targetPage === 'booking') {
            resetBookingForm();
            renderBookingStatus(); // Render initial booking status
        }
    }
    currentPage = targetPage;
    announceToScreenReader(`${pageTitle.textContent} page loaded.`);
}

/**
 * Toggles the visibility of a dashboard module.
 * @param {string} moduleId - The ID of the module content to toggle.
 */
function toggleModule(moduleId) {
    const moduleContent = document.getElementById(moduleId);
    const moduleHeader = moduleContent.previousElementSibling; // The button is the previous sibling

    if (moduleContent.classList.contains('active')) {
        moduleContent.classList.remove('active');
        moduleHeader.classList.remove('active');
        moduleHeader.querySelector('.module-icon').classList.remove('active');
        announceToScreenReader(`Module ${moduleContent.id} collapsed.`);
    } else {
        // Close other open modules (optional, but good for single-open module behavior)
        document.querySelectorAll('.module-content.active').forEach(openModule => {
            openModule.classList.remove('active');
            openModule.previousElementSibling.classList.remove('active');
            openModule.previousElementSibling.querySelector('.module-icon').classList.remove('active');
        });

        moduleContent.classList.add('active');
        moduleHeader.classList.add('active');
        moduleHeader.querySelector('.module-icon').classList.add('active');
        announceToScreenReader(`Module ${moduleContent.id} expanded.`);
    }
}

/**
 * Toggles the visibility of the three-dot module options menu.
 * @param {HTMLElement} dotMenuElement - The .module-options-dot-menu element.
 */
function toggleModuleOptions(dotMenuElement) {
    const optionsContent = dotMenuElement.querySelector('.module-options-content');
    // Close any other open option menus
    document.querySelectorAll('.module-options-content').forEach(menu => {
        if (menu !== optionsContent) {
            menu.style.display = 'none';
        }
    });
    optionsContent.style.display = optionsContent.style.display === 'block' ? 'none' : 'block';
    announceToScreenReader(`Module options for ${dotMenuElement.closest('.module-card').dataset.moduleId} toggled.`);
}

/**
 * Hides a specific dashboard module.
 * @param {string} moduleId - The ID of the module to hide.
 */
function hideModule(moduleId) {
    const moduleCard = document.querySelector(`.module-card[data-module-id="${moduleId}"]`);
    if (moduleCard) {
        moduleCard.style.display = 'none';
        // Store preference (client-side only for this demo)
        let hiddenModules = JSON.parse(localStorage.getItem('hiddenModules') || '[]');
        if (!hiddenModules.includes(moduleId)) {
            hiddenModules.push(moduleId);
            localStorage.setItem('hiddenModules', JSON.stringify(hiddenModules));
        }
        showMessageBox('Module Hidden', `The "${moduleId}" module is now hidden. Click "Customize Dashboard" to show it again.`);
    }
    // Close the options menu after clicking hide
    document.querySelectorAll('.module-options-content').forEach(menu => menu.style.display = 'none');
}

/**
 * Toggles the customize dashboard panel, revealing hidden modules.
 */
function toggleCustomizeDashboard() {
    const hiddenModules = JSON.parse(localStorage.getItem('hiddenModules') || '[]');
    if (hiddenModules.length > 0) {
        let message = 'Currently hidden modules: ';
        hiddenModules.forEach(moduleId => {
            message += `<br>- ${moduleId} <button onclick="showModule('${moduleId}')" class="w3-button w3-small w3-round-large primary-bg w3-margin-left">Show</button>`;
        });
        showMessageBox('Customize Dashboard', message);
    } else {
        showMessageBox('Customize Dashboard', 'All modules are currently visible.');
    }
}

/**
 * Shows a previously hidden dashboard module.
 * @param {string} moduleId - The ID of the module to show.
 */
function showModule(moduleId) {
    const moduleCard = document.querySelector(`.module-card[data-module-id="${moduleId}"]`);
    if (moduleCard) {
        moduleCard.style.display = 'block';
        // Remove from hidden preferences
        let hiddenModules = JSON.parse(localStorage.getItem('hiddenModules') || '[]');
        hiddenModules = hiddenModules.filter(id => id !== moduleId);
        localStorage.setItem('hiddenModules', JSON.stringify(hiddenModules));
        showMessageBox('Module Shown', `The "${moduleId}" module is now visible.`);
        closeModal('messageBox'); // Close the customize dashboard message box
    }
}

/**
 * Applies module visibility preferences loaded from local storage.
 */
function applyModuleVisibility() {
    const hiddenModules = JSON.parse(localStorage.getItem('hiddenModules') || '[]');
    document.querySelectorAll('.module-card').forEach(moduleCard => {
        const moduleId = moduleCard.dataset.moduleId;
        if (hiddenModules.includes(moduleId)) {
            moduleCard.style.display = 'none';
        } else {
            moduleCard.style.display = 'block';
        }
    });
}


// --- Authentication & User Management ---

/**
 * Handles the login form submission.
 * @param {Event} event - The submit event.
 */
function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('psw').value;

    const mockUser = mockUsers.find(u => u.email === email);

    if (mockUser && password === 'password123') { // Simple password check
        currentUser = { ...mockUser, lastLogin: new Date().toLocaleString() }; // Update last login
        isAdmin = currentUser.role === 'admin';
        localStorage.setItem('marketUser', JSON.stringify(currentUser));
        showMainApp();
        showMessageBox('Login Successful', `Welcome, ${currentUser.email}!`);
    } else {
        showMessageBox('Login Failed', 'Invalid email or password.');
    }
}

/**
 * Handles password change form submission (mocked).
 * @param {Event} event - The submit event.
 */
function handlePasswordChange(event) {
    event.preventDefault();
    const currentPsw = document.getElementById('currentPsw').value;
    const newPsw = document.getElementById('newPsw').value;
    const confirmNewPsw = document.getElementById('confirmNewPsw').value;

    if (currentPsw === 'password123' && newPsw === confirmNewPsw && newPsw !== '') {
        showMessageBox('Password Changed', 'Your password has been successfully updated (frontend simulation).');
        closeModal('passwordModal');
    } else {
        showMessageBox('Password Change Failed', 'Please check your current password and ensure new passwords match.');
    }
}

/**
 * Handles user logout.
 */
function handleLogout() {
    currentUser = null;
    isAdmin = false;
    localStorage.removeItem('marketUser');
    cart = [];
    localStorage.removeItem('marketCart');
    updateCartItemCount();
    showLoginPage();
    showMessageBox('Logged Out', 'You have been successfully logged out.');
}

// --- Product Management (Frontend Only) ---

/**
 * Renders products to the product grid.
 * @param {Array} productList - The array of products to render.
 * @param {HTMLElement} targetGrid - The DOM element to render products into.
 */
function renderProductCards(productList, targetGrid) {
    targetGrid.innerHTML = '';
    if (productList.length === 0) {
        targetGrid.innerHTML = '<p class="w3-center w3-text-grey">No products available yet.</p>';
        return;
    }

    productList.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'w3-col product-card animate-fade-in-up';
        productCard.innerHTML = `
            <img data-src="${product.image}" alt="${product.name}" class="lazy-load" onerror="this.onerror=null;this.src='https://placehold.co/400x300/cccccc/333333?text=No+Image';">
            <div class="product-card-content">
                <h4>${product.name}</h4>
                <div class="ratings">${getStarRating(product.rating)} (${product.rating.toFixed(1)})</div>
                <p class="justified-text">${product.description}</p>
                <div class="price">$${product.price.toFixed(2)}</div>
                <button class="add-to-cart-btn animate-pulse-on-hover" data-product-id="${product.id}">Add to Cart</button>
            </div>
        `;
        targetGrid.appendChild(productCard);
    });

    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', (event) => {
            const productId = event.target.dataset.productId;
            addToCart(productId);
        });
    });
}

/**
 * Renders all products to the main product page.
 */
function renderProducts() {
    renderProductCards(products, productGrid);
}

/**
 * Renders a subset of products for the dashboard's "Top Selling Products" section.
 */
function renderTopSellingProducts() {
    // For demo, just take the first few products or sort by a mock sales count
    const topProducts = [...products].sort((a, b) => b.rating - a.rating).slice(0, 4);
    renderProductCards(topProducts, topSellingProductsGrid);
}

/**
 * Handles adding a new product (admin function, frontend only).
 * @param {Event} event - The submit event.
 */
function handleAddProduct(event) {
    event.preventDefault();
    if (!isAdmin) {
        showMessageBox('Permission Denied', 'You must be an admin to add products.');
        return;
    }

    const name = document.getElementById('newProductName').value.trim();
    const price = parseFloat(document.getElementById('newProductPrice').value);
    const image = document.getElementById('newProductImage').value.trim();
    const description = document.getElementById('newProductDescription').value.trim();
    const rating = parseFloat(document.getElementById('newProductRating').value);

    if (name && !isNaN(price) && price > 0 && image && !isNaN(rating) && rating >= 1 && rating <= 5) {
        const newProduct = {
            id: 'p' + (products.length + 1),
            name: name,
            price: price,
            image: image,
            description: description,
            rating: rating
        };
        products.push(newProduct);
        renderProducts(); // Re-render all products
        renderTopSellingProducts(); // Update dashboard too
        setupLazyLoading(); // Re-apply lazy loading
        showMessageBox('Product Added', `"${name}" has been added to the product list.`);
        addProductForm.reset();
    } else {
        showMessageBox('Invalid Input', 'Please fill in all product details correctly (Name, Price > 0, Image URL, Rating 1-5).');
    }
}

// --- Cart System ---

/**
 * Adds a product to the cart or updates its quantity.
 * @param {string} productId - The ID of the product to add.
 */
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) {
        showMessageBox('Error', 'Product not found.');
        return;
    }

    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    saveCart();
    renderCart();
    updateCartItemCount();
    showMessageBox('Item Added', `${product.name} added to your cart.`);
}

/**
 * Renders the current state of the shopping cart.
 */
function renderCart() {
    cartItemsContainer.innerHTML = '';
    let total = 0;

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p class="w3-center justified-text w3-text-grey">Your cart is empty. Start shopping now to add items here!</p>';
        checkoutBtn.disabled = true;
    } else {
        cart.forEach(item => {
            const cartItemDiv = document.createElement('div');
            cartItemDiv.className = 'cart-item animate-fade-in';
            cartItemDiv.innerHTML = `
                <img src="${item.image}" alt="${item.name}" onerror="this.onerror=null;this.src='https://placehold.co/90x90/cccccc/333333?text=No+Image';">
                <div class="item-details">
                    <h4>${item.name}</h4>
                    <div class="price">$${item.price.toFixed(2)}</div>
                </div>
                <div class="item-quantity">
                    <button data-id="${item.id}" data-action="decrease">-</button>
                    <input type="number" value="${item.quantity}" min="1" data-id="${item.id}">
                    <button data-id="${item.id}" data-action="increase">+</button>
                </div>
                <button class="remove-item-btn" data-id="${item.id}"><i class="fas fa-trash"></i></button>
            `;
            cartItemsContainer.appendChild(cartItemDiv);
            total += item.price * item.quantity;
        });
        checkoutBtn.disabled = false;
    }

    cartTotalSpan.textContent = total.toFixed(2);
    updateCartItemCount();

    cartItemsContainer.querySelectorAll('.item-quantity button').forEach(button => {
        button.addEventListener('click', (event) => {
            const id = event.target.dataset.id;
            const action = event.target.dataset.action;
            updateCartQuantity(id, action);
        });
    });

    cartItemsContainer.querySelectorAll('.item-quantity input').forEach(input => {
        input.addEventListener('change', (event) => {
            const id = event.target.dataset.id;
            const newQuantity = parseInt(event.target.value);
            updateCartQuantity(id, 'set', newQuantity);
        });
    });

    cartItemsContainer.querySelectorAll('.remove-item-btn').forEach(button => {
        button.addEventListener('click', (event) => {
            const id = event.target.dataset.id;
            removeFromCart(id);
        });
    });
}

/**
 * Updates the quantity of an item in the cart.
 * @param {string} productId - The ID of the product.
 * @param {string} action - 'increase', 'decrease', or 'set'.
 * @param {number} [newQuantity] - The new quantity if action is 'set'.
 */
function updateCartQuantity(productId, action, newQuantity = null) {
    const itemIndex = cart.findIndex(item => item.id === productId);
    if (itemIndex > -1) {
        if (action === 'increase') {
            cart[itemIndex].quantity++;
        } else if (action === 'decrease') {
            cart[itemIndex].quantity--;
            if (cart[itemIndex].quantity <= 0) {
                removeFromCart(productId);
                return;
            }
        } else if (action === 'set' && newQuantity !== null && newQuantity >= 1) {
            cart[itemIndex].quantity = newQuantity;
        } else if (action === 'set' && newQuantity < 1) {
            removeFromCart(productId);
            return;
        }
        saveCart();
        renderCart();
    }
}

/**
 * Removes a product from the cart.
 * @param {string} productId - The ID of the product to remove.
 */
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    saveCart();
    renderCart();
    updateCartItemCount();
    showMessageBox('Item Removed', 'Product removed from cart.');
}

/**
 * Updates the cart item count displayed in the navigation.
 */
function updateCartItemCount() {
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartItemCountSpan.textContent = count;
}

/**
 * Saves the cart to localStorage (mock persistence).
 */
function saveCart() {
    localStorage.setItem('marketCart', JSON.stringify(cart));
}

/**
 * Loads the cart from localStorage on app start.
 */
function loadCart() {
    const savedCart = localStorage.getItem('marketCart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
    }
}

// --- Checkout and Payment (Frontend Simulation) ---

/**
 * Initiates the checkout process by opening the payment modal.
 */
function handleCheckout() {
    if (cart.length === 0) {
        showMessageBox('Cart Empty', 'Your cart is empty. Please add items before checking out.');
        return;
    }
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    document.getElementById('paymentTotal').textContent = total.toFixed(2);
    paymentModal.style.display = 'block';
    // Reset card display and flip state
    paymentCard.classList.remove('flipped');
    displayCardNumber.textContent = 'XXXX XXXX XXXX XXXX';
    displayCardName.textContent = 'CARDHOLDER NAME';
    displayExpiryDate.textContent = 'MM/YY';
    displayCvv.textContent = 'XXX';
    paymentForm.reset(); // Clear form inputs
    updatePaymentMethodFields(); // Show default payment method fields
    announceToScreenReader('Payment modal opened. Total amount is ' + total.toFixed(2) + ' dollars.');
}

/**
 * Validates payment input fields.
 * @returns {boolean} True if all required fields are valid, false otherwise.
 */
function validatePaymentInputs() {
    let isValid = true;

    // Reset all error messages
    hideInputError(cardNumberError);
    hideInputError(expiryDateError);
    hideInputError(cvvError);
    hideInputError(cardNameError);
    hideInputError(document.getElementById('paypalEmailError'));
    hideInputError(document.getElementById('bankAccountError'));


    const selectedMethod = paymentMethodSelect.value;

    if (selectedMethod === 'creditCard') {
        // Card Number validation
        if (!cardNumberInput.value.match(/^[0-9]{13,16}$/)) {
            showInputError(cardNumberError, 'Invalid card number (13-16 digits).');
            isValid = false;
        }

        // Expiry Date validation (MM/YY)
        const expiryMatch = expiryDateInput.value.match(/^(0[1-9]|1[0-2])\/?([0-9]{2})$/);
        if (!expiryMatch) {
            showInputError(expiryDateError, 'Invalid expiry date (MM/YY).');
            isValid = false;
        } else {
            const month = parseInt(expiryMatch[1], 10);
            const year = parseInt('20' + expiryMatch[2], 10); // Assuming 20XX
            const currentYear = new Date().getFullYear();
            const currentMonth = new Date().getMonth() + 1; // getMonth is 0-indexed

            if (year < currentYear || (year === currentYear && month < currentMonth)) {
                showInputError(expiryDateError, 'Card has expired.');
                isValid = false;
            }
        }

        // CVV validation
        if (!cvvInput.value.match(/^[0-9]{3,4}$/)) {
            showInputError(cvvError, 'Invalid CVV (3-4 digits).');
            isValid = false;
        }

        // Card Name validation
        if (cardNameInput.value.trim() === '') {
            showInputError(cardNameError, 'Name on card is required.');
            isValid = false;
        }
    } else if (selectedMethod === 'paypal') {
        if (!paypalEmailInput.value.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)) {
            showInputError(createErrorSpan('paypalEmailError'), 'Please enter a valid Digital Wallet email.');
            isValid = false;
        }
    } else if (selectedMethod === 'bankTransfer') {
        if (bankAccountInput.value.trim() === '' || !bankAccountInput.value.match(/^[0-9]{8,18}$/)) { // Example simple validation
            showInputError(createErrorSpan('bankAccountError'), 'Please enter a valid bank account number.');
            isValid = false;
        }
    }

    return isValid;
}


/**
 * Handles the payment form submission (frontend simulation).
 * @param {Event} event - The submit event.
 */
function handlePayment(event) {
    event.preventDefault();

    if (!validatePaymentInputs()) {
        showMessageBox('Validation Error', 'Please correct the errors in the form.');
        return;
    }

    showLoadingSpinner(); // Show loading spinner
    announceToScreenReader('Processing payment.');

    setTimeout(() => {
        hideLoadingSpinner(); // Hide loading spinner

        const success = Math.random() > 0.1; // 90% chance of success

        paymentFeedback.style.display = 'block';
        if (success) {
            paymentFeedback.classList.remove('error');
            paymentFeedback.classList.add('success');
            paymentFeedback.textContent = 'Payment Successful!';
            showMessageBox('Payment Successful!', 'Your order has been placed. Thank you for your purchase!');
            cart = []; // Clear cart after successful payment
            saveCart();
            renderCart();
        } else {
            paymentFeedback.classList.remove('success');
            paymentFeedback.classList.add('error');
            paymentFeedback.textContent = 'Payment Failed!';
            showMessageBox('Payment Failed', 'There was an issue with your payment. Please try again.');
        }

        setTimeout(() => {
            paymentFeedback.style.display = 'none';
            closeModal('paymentModal');
        }, 1500); // Hide feedback after a short delay
    }, 2000); // Simulate 2 seconds processing time
}

/**
 * Updates the displayed card number on the payment card.
 */
function updateCardNumberDisplay() {
    let formattedNumber = cardNumberInput.value.replace(/\s/g, '').match(/.{1,4}/g);
    displayCardNumber.textContent = formattedNumber ? formattedNumber.join(' ') : 'XXXX XXXX XXXX XXXX';
    validatePaymentInputs(); // Re-validate on input
}

/**
 * Updates the displayed card name on the payment card.
 */
function updateCardNameDisplay() {
    displayCardName.textContent = cardNameInput.value.toUpperCase() || 'CARDHOLDER NAME';
    validatePaymentInputs(); // Re-validate on input
}

/**
 * Updates the displayed expiry date on the payment card.
 */
function updateExpiryDateDisplay() {
    displayExpiryDate.textContent = expiryDateInput.value || 'MM/YY';
    validatePaymentInputs(); // Re-validate on input
}

/**
 * Handles CVV input and flips the card.
 */
function handleCvvInput() {
    displayCvv.textContent = cvvInput.value || 'XXX';
    if (cvvInput.value.length > 0) {
        paymentCard.classList.add('flipped');
    } else {
        paymentCard.classList.remove('flipped');
    }
    validatePaymentInputs(); // Re-validate on input
}

/**
 * Toggles visibility of payment method specific fields.
 */
function updatePaymentMethodFields() {
    const selectedMethod = paymentMethodSelect.value;

    creditCardFields.style.display = 'none';
    paypalEmailContainer.style.display = 'none';
    bankTransferInfoContainer.style.display = 'none';

    // Reset validation errors for all fields when method changes
    hideInputError(cardNumberError);
    hideInputError(expiryDateError);
    hideInputError(cvvError);
    hideInputError(cardNameError);
    hideInputError(document.getElementById('paypalEmailError'));
    hideInputError(document.getElementById('bankAccountError'));


    // Set required attribute based on selected method
    cardNumberInput.required = false;
    expiryDateInput.required = false;
    cvvInput.required = false;
    cardNameInput.required = false;
    paypalEmailInput.required = false;
    bankAccountInput.required = false;


    if (selectedMethod === 'creditCard') {
        creditCardFields.style.display = 'block';
        cardNumberInput.required = true;
        expiryDateInput.required = true;
        cvvInput.required = true;
        cardNameInput.required = true;
    } else if (selectedMethod === 'paypal') {
        paypalEmailContainer.style.display = 'block';
        paypalEmailInput.required = true;
    } else if (selectedMethod === 'bankTransfer') {
        bankTransferInfoContainer.style.display = 'block';
        bankAccountInput.required = true;
    }
}


// --- Orders (Mock) ---

/**
 * Renders mock orders.
 */
function renderOrders() {
    const ordersList = document.getElementById('ordersList');
    ordersList.innerHTML = `
        <p class="w3-center justified-text w3-text-grey">No past orders found for this session (frontend simulation).</p>
        <p class="w3-center justified-text w3-text-grey">Orders would appear here after a successful backend transaction.</p>
    `;
}

// --- Admin User List (Mock) ---

/**
 * Renders the mock list of users for the admin panel.
 */
function renderUsers() {
    userListBody.innerHTML = '';
    mockUsers.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${user.id}</td>
            <td>${user.email}</td>
            <td>${user.role}</td>
        `;
        userListBody.appendChild(row);
    });
}

// --- Chart.js Integration for Dashboard Analytics ---

function renderCharts() {
    // Destroy existing chart instances if they exist
    if (revenueChartInstance) {
        revenueChartInstance.destroy();
    }
    if (categoryChartInstance) {
        categoryChartInstance.destroy();
    }

    // Revenue Chart (Line Chart)
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    revenueChartInstance = new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Monthly Revenue ($)',
                data: [1200, 1900, 3000, 5000, 2300, 4500],
                borderColor: 'var(--primary)', // Primary blue
                backgroundColor: 'rgba(74, 144, 226, 0.2)',
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });

    // Product Categories Chart (Doughnut Chart)
    const categoryCtx = document.getElementById('categoryChart').getContext('2d');
    categoryChartInstance = new Chart(categoryCtx, {
        type: 'doughnut',
        data: {
            labels: ['Electronics', 'Home Goods', 'Apparel', 'Books'],
            datasets: [{
                data: [300, 150, 200, 100],
                backgroundColor: ['var(--primary)', 'var(--analogous-green)', 'var(--accent)', 'var(--info)'], // Custom colors
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
        }
    });
}

// --- Online Booking Module (Simulated) ---

/**
 * Resets the booking form and tracking display.
 */
function resetBookingForm() {
    bookingForm.reset();
    currentBooking = null;
    clearInterval(bookingStatusInterval);
    orderTrackingDisplay.querySelector('.w3-large').style.display = 'block'; // Show "No active orders"
    bookingOrderStatus.style.display = 'none';
    bookingLocationUpdate.style.display = 'none';
    // Reset status steps
    document.querySelectorAll('.status-step').forEach((step, index) => {
        step.classList.remove('active');
        if (index === 0) step.classList.add('active'); // "Order Placed" is active by default
    });
    // Clear validation errors
    hideInputError(pickupAddressError);
    hideInputError(deliveryAddressError);
}

/**
 * Handles booking form submission (simulated).
 * @param {Event} event - The submit event.
 */
function handleBooking(event) {
    event.preventDefault();

    const orderName = document.getElementById('orderName').value.trim();
    const orderDetails = document.getElementById('orderDetails').value.trim();
    const pickupAddress = document.getElementById('pickupAddress').value.trim();
    const deliveryAddress = document.getElementById('deliveryAddress').value.trim();
    const bookingPrice = parseFloat(document.getElementById('bookingPrice').value);
    const bookingPaymentMethod = document.getElementById('bookingPaymentMethod').value;

    // Basic frontend validation for addresses
    let isValid = true;
    hideInputError(pickupAddressError);
    hideInputError(deliveryAddressError);

    if (pickupAddress === '') {
        showInputError(pickupAddressError, 'Pickup address is required.');
        isValid = false;
    }
    if (deliveryAddress === '') {
        showInputError(deliveryAddressError, 'Delivery address is required.');
        isValid = false;
    }
    if (orderName === '') {
        showMessageBox('Validation Error', 'Order Name/Service is required.');
        isValid = false;
    }
    if (isNaN(bookingPrice) || bookingPrice <= 0) {
        showMessageBox('Validation Error', 'Estimated Price must be a positive number.');
        isValid = false;
    }

    if (!isValid) {
        return;
    }

    currentBooking = {
        id: 'B' + Date.now(), // Simple unique ID
        orderName: orderName,
        orderDetails: orderDetails,
        pickupAddress: pickupAddress,
        deliveryAddress: deliveryAddress,
        price: bookingPrice,
        paymentMethod: bookingPaymentMethod,
        status: 0, // 0: Placed, 1: Processing, 2: On the Way, 3: Delivered
        currentLocation: 'Awaiting assignment...'
    };

    showMessageBox('Booking Confirmed', `Your booking for "${orderName}" has been placed! Tracking will begin shortly.`);
    renderBookingStatus();
    startBookingStatusUpdates();
}

/**
 * Renders the current booking status and location.
 */
function renderBookingStatus() {
    if (!currentBooking) {
        orderTrackingDisplay.querySelector('.w3-large').style.display = 'block';
        bookingOrderStatus.style.display = 'none';
        bookingLocationUpdate.style.display = 'none';
        return;
    }

    orderTrackingDisplay.querySelector('.w3-large').style.display = 'none';
    bookingOrderStatus.style.display = 'flex';
    bookingLocationUpdate.style.display = 'block';

    // Update status timeline
    const statusSteps = bookingOrderStatus.querySelectorAll('.status-step');
    statusSteps.forEach((step, index) => {
        if (index <= currentBooking.status) {
            step.classList.add('active');
        } else {
            step.classList.remove('active');
        }
    });

    // Update current location text
    currentLocationText.textContent = currentBooking.currentLocation;
}

/**
 * Simulates real-time order status and location updates.
 */
function startBookingStatusUpdates() {
    clearInterval(bookingStatusInterval); // Clear any existing interval

    const locations = [
        "Service provider assigned, heading to pickup.",
        "Arrived at pickup location.",
        "On the way to delivery address.",
        "Approaching delivery address (5 mins away).",
        "Arrived at delivery location."
    ];
    const statuses = [
        "Order Placed",
        "Processing",
        "On the Way",
        "Delivered"
    ];

    let locationIndex = 0;

    bookingStatusInterval = setInterval(() => {
        if (!currentBooking) {
            clearInterval(bookingStatusInterval);
            return;
        }

        // Simulate status progression
        if (currentBooking.status < statuses.length - 1 && Math.random() > 0.6) { // Randomly advance status
            currentBooking.status++;
        }

        // Simulate location updates
        if (currentBooking.status < 3 && locationIndex < locations.length) { // Update location until delivered
            currentBooking.currentLocation = locations[locationIndex];
            locationIndex++;
        } else if (currentBooking.status === 3) {
            currentBooking.currentLocation = "Order delivered successfully!";
            clearInterval(bookingStatusInterval); // Stop updates once delivered
            showMessageBox('Order Delivered', `Your order "${currentBooking.orderName}" has been delivered!`);
        }

        renderBookingStatus();
    }, 3000); // Update every 3 seconds
}


// --- Event Listeners Setup ---

function setupEventListeners() {
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    if (passwordForm) {
        passwordForm.addEventListener('submit', handlePasswordChange);
    }

    if (paymentForm) {
        paymentForm.addEventListener('submit', handlePayment);
        cardNumberInput.addEventListener('input', updateCardNumberDisplay);
        cardNameInput.addEventListener('input', updateCardNameDisplay);
        expiryDateInput.addEventListener('input', updateExpiryDateDisplay);
        cvvInput.addEventListener('input', handleCvvInput);
        cvvInput.addEventListener('blur', () => {
            if (cvvInput.value.length === 0) {
                paymentCard.classList.remove('flipped');
            }
        });
        paymentMethodSelect.addEventListener('change', updatePaymentMethodFields);

        // Add input event listeners for validation
        cardNumberInput.addEventListener('input', () => validatePaymentInputs());
        expiryDateInput.addEventListener('input', () => validatePaymentInputs());
        cvvInput.addEventListener('input', () => validatePaymentInputs());
        cardNameInput.addEventListener('input', () => validatePaymentInputs());
        if (paypalEmailInput) paypalEmailInput.addEventListener('input', () => validatePaymentInputs());
        if (bankAccountInput) bankAccountInput.addEventListener('input', () => validatePaymentInputs());
    }

    // New user settings dropdown
    if (userSettingsDropdownBtn) {
        userSettingsDropdownBtn.addEventListener('click', (event) => {
            event.stopPropagation(); // Prevent document click from closing immediately
            const dropdownContent = userSettingsDropdownBtn.nextElementSibling;
            dropdownContent.style.display = dropdownContent.style.display === 'block' ? 'none' : 'block';
            announceToScreenReader('User settings dropdown toggled.');
        });
        // Close dropdown if clicked outside
        document.addEventListener('click', (event) => {
            const dropdownContent = userSettingsDropdownBtn.nextElementSibling;
            if (dropdownContent && !userSettingsDropdownBtn.contains(event.target) && !dropdownContent.contains(event.target)) {
                dropdownContent.style.display = 'none';
            }
        });
    }


    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', handleNavigation);
    });

    // Quick Start buttons
    document.querySelectorAll('.quick-start-grid button').forEach(button => {
        button.addEventListener('click', handleNavigation);
    });

    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    if (changePasswordBtn) {
        changePasswordBtn.addEventListener('click', () => {
            closeModal('messageBox'); // Close any open message box
            passwordModal.style.display = 'block';
            announceToScreenReader('Change password modal opened.');
        });
    }
    if (userManagementBtn) {
        userManagementBtn.addEventListener('click', () => {
            closeModal('messageBox'); // Close any open message box
            handleNavigation({ target: document.querySelector('.nav-item[data-page="admin"]') });
            // Close settings dropdown
            userSettingsDropdownBtn.nextElementSibling.style.display = 'none';
        });
    }

    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', handleCheckout);
    }

    if (addProductForm) {
        addProductForm.addEventListener('submit', handleAddProduct);
    }

    if (bookingForm) {
        bookingForm.addEventListener('submit', handleBooking);
        document.getElementById('pickupAddress').addEventListener('input', () => hideInputError(pickupAddressError));
        document.getElementById('deliveryAddress').addEventListener('input', () => hideInputError(deliveryAddressError));
    }

    // Close module options when clicking outside
    document.addEventListener('click', (event) => {
        document.querySelectorAll('.module-options-content').forEach(menu => {
            const dotMenu = menu.closest('.module-options-dot-menu');
            if (dotMenu && !dotMenu.contains(event.target)) {
                menu.style.display = 'none';
            }
        });
    });
}

// --- Simple Slideshow JS for demo (Enhanced) ---
let slideIndex = 1;
let slideshowInterval; // Variable to hold the interval ID for auto-play

/**
 * Starts the auto-play for the slideshow.
 */
function startSlideshowAutoPlay() {
    // Clear any existing interval to prevent multiple auto-plays
    clearInterval(slideshowInterval);
    slideshowInterval = setInterval(() => {
        plusSlides(1); // Move to the next slide
    }, 5000); // Change slide every 5 seconds
}

/**
 * Stops the auto-play for the slideshow.
 */
function stopSlideshowAutoPlay() {
    clearInterval(slideshowInterval);
}

function plusSlides(n) {
    showSlides(slideIndex += n);
    stopSlideshowAutoPlay(); // Stop auto-play on manual navigation
    startSlideshowAutoPlay(); // Restart auto-play after a short delay
}

function currentSlide(n) {
    showSlides(slideIndex = n);
    stopSlideshowAutoPlay(); // Stop auto-play on manual navigation
    startSlideshowAutoPlay(); // Restart auto-play after a short delay
}

function showSlides(n) {
    let i;
    const slides = document.getElementsByClassName("slide-item");
    const dots = document.getElementsByClassName("dot");

    if (slides.length === 0) return; // Exit if no slides

    if (n > slides.length) { slideIndex = 1; }
    if (n < 1) { slideIndex = slides.length; }

    for (i = 0; i < slides.length; i++) {
        slides[i].classList.remove('active');
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].classList.remove('active-dot');
    }

    slides[slideIndex - 1].classList.add('active');
    dots[slideIndex - 1].classList.add('active-dot');
}

// --- Lazy Loading for Images ---

/**
 * Sets up Intersection Observer for lazy loading images.
 */
function setupLazyLoading() {
    const lazyImages = document.querySelectorAll('img.lazy-load');

    if ('IntersectionObserver' in window) {
        let lazyLoadObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    let lazyImage = entry.target;
                    lazyImage.src = lazyImage.dataset.src;
                    lazyImage.classList.remove('lazy-load');
                    lazyLoadObserver.unobserve(lazyImage);
                }
            });
        });

        lazyImages.forEach(function(lazyImage) {
            lazyLoadObserver.observe(lazyImage);
        });
    } else {
        // Fallback for browsers that don't support Intersection Observer
        lazyImages.forEach(function(lazyImage) {
            lazyImage.src = lazyImage.dataset.src;
            lazyImage.classList.remove('lazy-load');
        });
    }
}

// Initialize slideshow on window load
window.onload = function() {
    showSlides(slideIndex); // Show the first slide initially
    startSlideshowAutoPlay(); // Start auto-play
    setupLazyLoading(); // Ensure lazy loading is applied after content is rendered
    renderCharts(); // Render charts on initial dashboard load
    applyModuleVisibility(); // Apply module visibility on load
};
