// routes/auth.js
// This file defines the API routes for user authentication.

const express = require('express');
const router = express.Router();
const { registerUser, loginUser, getUserProfile } = require('../controllers/authController');
const { protect } = require('../middleware/authMiddleware');

// Public routes
router.post('/register', registerUser); // Route for new user registration
router.post('/login', loginUser);     // Route for user login

// Private routes (require JWT authentication)
router.get('/profile', protect, getUserProfile); // Route to get authenticated user's profile

module.exports = router;