// controllers/authController.js
// This file contains the logic for user authentication (registration and login).

const User = require('../models/User'); // Import the User model
const jwt = require('jsonwebtoken');     // For creating JWT tokens
const asyncHandler = require('express-async-handler'); // Simple wrapper for async middleware to handle errors

// Helper function to generate a JWT token
const generateToken = (id) => {
    // Sign the token with user ID, JWT secret from environment variables, and expiration
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '1h', // Token expires in 1 hour
    });
};

/**
 * @desc    Register a new user
 * @route   POST /api/auth/register
 * @access  Public
 */
const registerUser = asyncHandler(async (req, res) => {
    const { username, email, password, role } = req.body;

    // Input validation
    if (!username || !email || !password) {
        res.status(400); // Bad request
        throw new Error('Please enter all fields: username, email, and password');
    }

    // Check if user already exists
    const userExists = await User.findOne({ email });
    if (userExists) {
        res.status(400); // Bad request
        throw new Error('User with this email already exists');
    }

    // Create new user
    const user = await User.create({
        username,
        email,
        password, // Password will be hashed by the pre-save hook in User model
        role: role || 'user' // Default role to 'user' if not provided
    });

    if (user) {
        res.status(201).json({ // 201 Created
            _id: user._id,
            username: user.username,
            email: user.email,
            role: user.role,
            token: generateToken(user._id), // Generate and send JWT token
        });
    } else {
        res.status(400);
        throw new Error('Invalid user data');
    }
});

/**
 * @desc    Authenticate user & get token
 * @route   POST /api/auth/login
 * @access  Public
 */
const loginUser = asyncHandler(async (req, res) => {
    const { email, password } = req.body;

    // Input validation
    if (!email || !password) {
        res.status(400);
        throw new Error('Please enter email and password');
    }

    // Check for user by email
    const user = await User.findOne({ email });

    // Check if user exists and password matches
    if (user && (await user.matchPassword(password))) {
        res.json({
            _id: user._id,
            username: user.username,
            email: user.email,
            role: user.role,
            token: generateToken(user._id), // Generate and send JWT token
        });
    } else {
        res.status(401); // Unauthorized
        throw new Error('Invalid email or password');
    }
});

/**
 * @desc    Get current user profile
 * @route   GET /api/auth/profile
 * @access  Private (requires JWT)
 */
const getUserProfile = asyncHandler(async (req, res) => {
    // req.user is populated by the 'protect' middleware
    const user = await User.findById(req.user._id).select('-password'); // Exclude password

    if (user) {
        res.json({
            _id: user._id,
            username: user.username,
            email: user.email,
            role: user.role,
            createdAt: user.createdAt,
            updatedAt: user.updatedAt
        });
    } else {
        res.status(404); // Not Found
        throw new Error('User not found');
    }
});

module.exports = {
    registerUser,
    loginUser,
    getUserProfile
};

