// server.js
// This is the main entry point for the Node.js Express backend application.

// Load environment variables from .env file
require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors'); // For handling Cross-Origin Resource Sharing
const path = require('path'); // Node.js built-in module for path manipulation

// Import database connection function
const connectDB = require('./config/db');

// Import routes
const authRoutes = require('./routes/auth');
const fileRoutes = require('./routes/file');

// Import custom middleware
const errorHandler = require('./middleware/errorHandler');

// Initialize Express app
const app = express();

// Connect to MongoDB
connectDB();

// Middleware
// Enable CORS for all origins (adjust for production to specific origins)
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000', // Allow requests from your frontend
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'], // Allowed HTTP methods
    allowedHeaders: ['Content-Type', 'Authorization'], // Allowed headers
    credentials: true // Allow cookies/authorization headers to be sent
}));

// Body parser middleware to parse JSON requests
app.use(express.json());

// Serve static files from the 'uploads' directory
// This allows files stored locally to be accessed via a URL
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Simple request logger middleware
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.originalUrl}`);
    next();
});

// Define API routes
app.use('/api/auth', authRoutes); // Authentication routes (e.g., /api/auth/register, /api/auth/login)
app.use('/api/files', fileRoutes); // File management routes (e.g., /api/files/upload, /api/files/:id)

// Basic root route
app.get('/', (req, res) => {
    res.send('MarketHub Backend API is running!');
});

// Centralized error handling middleware (must be last middleware)
app.use(errorHandler);

// Define the port to listen on
const PORT = process.env.PORT || 5000;

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

