// models/File.js
// This file defines the Mongoose schema and model for storing metadata about uploaded files.

const mongoose = require('mongoose');

const fileSchema = new mongoose.Schema({
    filename: {
        type: String,
        required: true,
        unique: true // Ensure filenames are unique
    },
    originalname: {
        type: String,
        required: true
    },
    mimetype: {
        type: String,
        required: true
    },
    size: {
        type: Number,
        required: true
    },
    path: { // The path where the file is stored on the server
        type: String,
        required: true
    },
    uploadedBy: {
        type: mongoose.Schema.Types.ObjectId, // Reference to the User who uploaded the file
        ref: 'User', // Refers to the 'User' model
        required: true
    },
    uploadDate: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true // Adds createdAt and updatedAt timestamps
});

const File = mongoose.model('File', fileSchema);

module.exports = File;

