// routes/file.js
// This file defines the API routes for file upload, retrieval, and deletion.

const express = require('express');
const router = express.Router();
const multer = require('multer'); // Middleware for handling multipart/form-data (file uploads)
const { uploadFile, getMyFiles, downloadFile, deleteFile } = require('../controllers/fileController');
const { protect, authorizeAdmin } = require('../middleware/authMiddleware');
const path = require('path'); // Node.js built-in module for path manipulation

// --- Multer Configuration for File Uploads ---

// Define storage for uploaded files
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        // Set the destination directory for uploaded files
        // The 'uploads' directory should be created in the root of your backend project
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        // Generate a unique filename to prevent overwrites and ensure uniqueness
        // Appends a timestamp and original extension to the fieldname
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

// File filter to allow specific file types and prevent malicious uploads
const fileFilter = (req, file, cb) => {
    // Allowed file extensions (beyond standard three)
    const allowedExtensions = [
        '.jpg', '.jpeg', '.png', '.gif', // Images
        '.pdf',                         // Documents
        '.doc', '.docx',                // Microsoft Word documents
        '.xls', '.xlsx',                // Microsoft Excel spreadsheets
        '.ppt', '.pptx',                // Microsoft PowerPoint presentations
        '.txt', '.csv',                 // Text and data files
        '.zip', '.rar',                 // Archives
        '.mp3', '.wav',                 // Audio
        '.mp4', '.avi',                 // Video
        // Add more as needed
    ];

    // Check file extension
    const ext = path.extname(file.originalname).toLowerCase();
    if (!allowedExtensions.includes(ext)) {
        // Reject file: pass false and an error message
        return cb(new Error('File type not allowed!'), false);
    }

    // Check mimetype (more robust than just extension)
    const allowedMimeTypes = [
        'image/jpeg', 'image/png', 'image/gif',
        'application/pdf',
        'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'text/plain', 'text/csv',
        'application/zip', 'application/x-rar-compressed',
        'audio/mpeg', 'audio/wav',
        'video/mp4', 'video/x-msvideo'
    ];
    if (!allowedMimeTypes.includes(file.mimetype)) {
        return cb(new Error('File MIME type not allowed!'), false);
    }

    // Accept file
    cb(null, true);
};

// Initialize multer upload middleware
const upload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 1024 * 1024 * 10 // 10 MB file size limit
    }
});

// --- File Routes ---

// Route for uploading a single file. 'protect' ensures user is authenticated.
router.post('/upload', protect, upload.single('file'), uploadFile);

// Route to get all files uploaded by the authenticated user.
router.get('/', protect, getMyFiles);

// Route to download a specific file by its ID.
// User must own the file or be an admin to download.
router.get('/download/:id', protect, downloadFile);

// Route to delete a specific file by its ID.
// User must own the file or be an admin to delete.
router.delete('/:id', protect, deleteFile);

module.exports = router;

