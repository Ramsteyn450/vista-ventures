// middleware/errorHandler.js
// This file provides a centralized error handling middleware for Express.

const errorHandler = (err, req, res, next) => {
    // Determine the status code: use the error's status code or default to 500 (Internal Server Error)
    const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
    res.status(statusCode);

    // Send a JSON response with the error message and stack trace (in development)
    res.json({
        message: err.message,
        // Include stack trace only in development environment for debugging
        stack: process.env.NODE_ENV === 'production' ? null : err.stack,
    });
};

module.exports = errorHandler;

